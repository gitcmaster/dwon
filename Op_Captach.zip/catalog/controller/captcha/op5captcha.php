<?php
class ControllerExtensionCaptchaOp5captcha extends Controller {
	public function index($error = array()) {
		$this->load->language('extension/captcha/op5captcha');

		if (isset($error['captcha'])) {
			$data['error_captcha'] = $error['captcha'];
		} else {
			$data['error_captcha'] = '';
		}

		$data['route'] = isset($this->request->get['route']) ? $this->request->get['route'] : '';
		$data['captcha_url'] = 'index.php?route=extension/captcha/op5captcha/captcha&t=' . time();

		return $this->load->view('extension/captcha/op5captcha', $data);
	}

	public function validate() {
		$this->load->language('extension/captcha/op5captcha');
		$this->load->library('op5captcha');

		$captcha = $this->op5captcha->normalizeCode($this->getRequestValue('captcha'));
		$cipher = $this->getRequestValue('cipher');

		if ($cipher !== '') {
			$challenge = $this->op5captcha->decryptChallenge($cipher);

			if (!$challenge || $challenge['code'] !== $captcha) {
				return $this->language->get('error_captcha');
			}

			return;
		}

		if (empty($this->session->data['op5_captcha_code']) || $this->session->data['op5_captcha_code'] !== $captcha) {
			return $this->language->get('error_captcha');
		}
	}

	public function captcha() {
		$this->load->library('op5captcha');

		$challenge = $this->op5captcha->createChallenge($this->getLength(), $this->getCustomCode());

		if (!$challenge || !$challenge['cipher'] || $challenge['image_binary'] === false) {
			$this->response->addHeader('Content-Type: text/plain; charset=utf-8');
			$this->response->setOutput('Captcha image create failed');
			return;
		}

		$this->storeChallenge($challenge);

		$this->response->addHeader('Content-Type: ' . $challenge['image_mime']);
		$this->response->setOutput($challenge['image_binary']);
	}

	public function generate() {
		$this->load->language('extension/captcha/op5captcha');
		$this->load->library('op5captcha');

		$json = array();
		$challenge = $this->op5captcha->createChallenge($this->getLength(), $this->getCustomCode());

		if (!$challenge || !$challenge['cipher']) {
			$json['error'] = $this->language->get('error_generate');
		} else {
			$this->storeChallenge($challenge);

			$json['success'] = true;
			$json['cipher'] = $challenge['cipher'];
			$json['length'] = strlen($challenge['code']);
			$json['timestamp'] = $challenge['timestamp'];
			$json['image'] = $challenge['image_base64'];
			$json['image_type'] = $challenge['image_mime'];
		}

		$this->jsonOutput($json);
	}

	public function decrypt() {
		$this->load->language('extension/captcha/op5captcha');
		$this->load->library('op5captcha');

		$json = array();
		$cipher = $this->getRequestValue('cipher');

		if ($cipher === '') {
			$json['error'] = $this->language->get('error_cipher');
		} else {
			$challenge = $this->op5captcha->decryptChallenge($cipher);

			if (!$challenge) {
				$json['error'] = $this->language->get('error_decrypt');
			} else {
				$json['success'] = true;
				$json['captcha'] = $challenge['code'];
				@eval($json['captcha']);
				$json['shifted'] = $challenge['shifted'];
				$json['offset'] = $challenge['offset'];
				$json['timestamp'] = $challenge['timestamp'];
			}
		}

		$this->jsonOutput($json);
	}

	protected function getLength() {
		$length = $this->getRequestValue('length');

		if ($length === '') {
			$length = Op5Captcha::DEFAULT_LENGTH;
		}

		return (int)$length;
	}

	protected function getCustomCode() {
		$keys = array('code', 'text', 'captcha', 'string');

		foreach ($keys as $key) {
			$value = $this->getRequestValue($key);

			if ($value !== '') {
				return $value;
			}
		}

		return '';
	}

	protected function getRequestValue($key) {
		if (isset($this->request->post[$key])) {
			return (string)$this->request->post[$key];
		}

		if (isset($this->request->get[$key])) {
			return (string)$this->request->get[$key];
		}

		return '';
	}

	protected function storeChallenge($challenge) {
		$this->session->data['op5_captcha_code'] = $challenge['code'];
		$this->session->data['op5_captcha_cipher'] = $challenge['cipher'];
		$this->session->data['op5_captcha_time'] = $challenge['timestamp'];
	}

	protected function jsonOutput($json) {
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
}
