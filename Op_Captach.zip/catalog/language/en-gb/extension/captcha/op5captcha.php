<?php
// Text
$_['text_captcha'] = 'Captcha';

// Entry
$_['entry_captcha'] = 'Enter the code shown in the image below';

// Error
$_['error_captcha'] = 'Verification code does not match!';
$_['error_generate'] = 'Captcha generation failed!';
$_['error_cipher'] = 'Cipher text is required!';
$_['error_decrypt'] = 'Cipher text decrypt failed!';
