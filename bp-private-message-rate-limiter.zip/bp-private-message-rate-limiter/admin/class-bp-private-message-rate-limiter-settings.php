<?php
/**
 * Message rate limiter admin settings
 *
 * @package    BP Private Message Rate Limiter
 * @subpackage Admin
 * @copyright  Copyright (c) 2019, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

use Press_Themes\PT_Settings\Page;

/**
 * Class BP_Private_Message_Rate_Limiter_Settings
 */
class BP_Private_Message_Rate_Limiter_Settings {

	/**
	 * Page instance
	 *
	 * @var Page
	 */
	private $page;

	/**
	 * Menu slug
	 *
	 * @var string
	 */
	private $menu_slug = 'message-rate-limiter-settings';

	/**
	 * Boot class
	 */
	public static function boot() {
		$self = new self();
		$self->setup();
	}

	/**
	 * Setup actions
	 */
	private function setup() {
		add_action( 'admin_init', array( $this, 'init' ) );
		add_action( 'admin_menu', array( $this, 'add_menu' ) );
	}

	/**
	 * Is it the setting page?
	 *
	 * @return bool
	 */
	private function needs_loading() {

		global $pagenow;

		// We need to load on options.php otherwise settings won't be reistered.
		if ( 'options.php' === $pagenow ) {
			return true;
		}

		if ( isset( $_GET['page'] ) && $_GET['page'] === $this->menu_slug ) {
			return true;
		}

		return false;
	}

	/**
	 * Initialize the admin settings panel and fields
	 */
	public function init() {

		if ( ! $this->needs_loading() ) {
			return;
		}

		$page = new Page( 'private_message_rate_limiter_settings', __( 'BP Private Message Rate Limiter', 'bp-private-message-rate-limiter' ) );

		$page->use_unique_option();

		// General settings tab.
		$general = $page->add_panel( 'general', _x( 'General', 'Admin settings panel title', 'bp-private-message-rate-limiter' ) );

		$section_general = $general->add_section( 'settings', _x( 'BP Rate Limit Private Message', 'Admin settings section title', 'bp-private-message-rate-limiter' ) );

		$defaults = bp_private_message_rate_limiter_get_default_settings();

		$fields = array(
			array(
				'name'    => 'bp_rate_limit_pm_count',
				'label'   => _x( 'How many messages a user can send?', 'Admin settings', 'bp-private-message-rate-limiter' ),
				'type'    => 'text',
				'default' => $defaults['bp_rate_limit_pm_count'],
			),
			array(
				'name'    => 'bp_rate_limit_pm_throttle_duration',
				'label'   => _x( 'During the time?', 'Admin settings', 'bp-private-message-rate-limiter' ),
				'type'    => 'text',
				'default' => $defaults['bp_rate_limit_pm_throttle_duration'],
			),
			array(
				'name'    => 'bp_rate_limit_pm_type',
				'label'   => _x( 'Criteria?', 'Admin settings', 'bp-private-message-rate-limiter' ),
				'type'    => 'radio',
				'options' => array(
					'thread' => __( 'Only New Messages', 'bp-private-message-rate-limiter' ),
					'all'    => __( 'New message( including replies )', 'bp-private-message-rate-limiter' ),
				),
				'default' => $defaults['bp_rate_limit_pm_type'],
			),
			array(
				'name'    => 'bp_rate_limit_pm_hide_button',
				'label'   => _x( 'Hide message button?', 'Admin settings', 'bp-private-message-rate-limiter' ),
				'type'    => 'checkbox',
				'default' => $defaults['bp_rate_limit_pm_hide_button'],
			),
			array(
				'name'    => 'bp_rate_limit_pm_message',
				'label'   => _x( 'What message you want to display if the user reaches the limit?', 'Admin settings', 'bp-private-message-rate-limiter' ),
				'type'    => 'rawtext',
				'default' => $defaults['bp_rate_limit_pm_message'],
			),
		);

		$section_general->add_fields( $fields );

		$this->page = $page;

		// allow enabling options.
		$page->init();
	}

	/**
	 * Show/render the setting page
	 */
	public function render() {
		$this->page->render();
	}

	/**
	 * Add Menu
	 */
	public function add_menu() {
		add_options_page(
			_x( 'BP Private Message Rate Limiter', 'Admin settings page title', 'bp-private-message-rate-limiter' ),
			_x( 'BP Private Message Rate Limiter', 'Admin settings menu label', 'bp-private-message-rate-limiter' ),
			'manage_options',
			$this->menu_slug,
			array( $this, 'render' )
		);
	}
}