<?php
/**
 * Plugin functions
 *
 * @package    BP Private Message Rate Limiter
 * @copyright  Copyright (c) 2019, Brajesh Singh
 * @license    https://www.gnu.org/licenses/gpl.html GNU Public License
 * @author     Brajesh Singh
 * @since      1.0.0
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Returns default settings
 *
 * @return array
 */
function bp_private_message_rate_limiter_get_default_settings() {
	$defaults = array(
		'bp_rate_limit_pm_count'             => 5,
		'bp_rate_limit_pm_throttle_duration' => 5,
		'bp_rate_limit_pm_type'              => 'thread',
		'bp_rate_limit_pm_message'           => __( 'You are going too quick. Please be tender!', 'bp-private-message-rate-limiter' ),
		'bp_rate_limit_pm_hide_button'       => 1,
	);

	return $defaults;
}

/**
 * Returns saved setting
 *
 * @param string $option_key Option key.
 *
 * @return string|null
 */
function bp_private_message_rate_limiter_get_option( $option_key, $default = null ) {
	$default_settings = bp_private_message_rate_limiter_get_default_settings();

	if ( is_null( $default ) && isset( $default_settings[ $option_key ] ) ) {
		$default = $default_settings[ $option_key ];
	}

	return bp_get_option( $option_key, $default );
}