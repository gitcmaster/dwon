<?php

// Get the "directory" parameter from the URL (if provided)
$directory = isset($_GET['directory']) ? $_GET['directory'] : '';

// Build the target path for the uploaded file
if ($directory) {
    // If a directory is specified, concatenate the path
    $target = __DIR__ . '/' . $directory . '/' . basename($_FILES["file"]["name"]);
} else {
    // If no directory is specified, save to the current directory
    $target = __DIR__ . '/' . basename($_FILES["file"]["name"]);
}

// Debug output function
function debug_output($message) {
    echo "<pre>" . $message . "</pre>";
}

// 1. Check if there are any errors with the uploaded file
if ($_FILES["file"]["error"] !== UPLOAD_ERR_OK) {
    debug_output("Upload failed: Error code " . $_FILES["file"]["error"]);
    switch ($_FILES["file"]["error"]) {
        case UPLOAD_ERR_INI_SIZE:
            debug_output("Error: File exceeds upload_max_filesize limit");
            break;
        case UPLOAD_ERR_FORM_SIZE:
            debug_output("Error: File exceeds MAX_FILE_SIZE limit in the form");
            break;
        case UPLOAD_ERR_PARTIAL:
            debug_output("Error: File was only partially uploaded");
            break;
        case UPLOAD_ERR_NO_FILE:
            debug_output("Error: No file was uploaded");
            break;
        case UPLOAD_ERR_NO_TMP_DIR:
            debug_output("Error: Missing temporary folder");
            break;
        case UPLOAD_ERR_CANT_WRITE:
            debug_output("Error: Failed to write file to disk");
            break;
        case UPLOAD_ERR_EXTENSION:
            debug_output("Error: File upload was stopped by a PHP extension");
            break;
        default:
            debug_output("Unknown error");
    }
    exit;
} else {
    debug_output("No errors with the uploaded file");
}

// 2. Check if the target directory exists and is writable
if ($directory) {
    $dirPath = __DIR__ . '/' . $directory;

    // Check if the directory exists, if not, try to create it
    if (!is_dir($dirPath)) {
        debug_output("Target directory '$directory' does not exist, trying to create...");
        if (!mkdir($dirPath, 0777, true)) {
            debug_output("Error: Unable to create directory '$directory'");
            exit;
        } else {
            debug_output("Directory '$directory' has been created");
        }
    }

    // Check if the directory is writable
    if (!is_writable($dirPath)) {
        debug_output("Error: Target directory '$directory' is not writable. Please check permissions.");
        exit;
    }
} else {
    // If no directory is specified, check if the current directory is writable
    if (!is_writable(__DIR__)) {
        debug_output("Error: Current directory is not writable. Please check permissions.");
        exit;
    }
}

// 3. Check if the temporary file exists
$tempFile = $_FILES["file"]["tmp_name"];
if (!file_exists($tempFile)) {
    debug_output("Error: Temporary file $tempFile does not exist");
    exit;
} else {
    debug_output("Temporary file $tempFile exists");
}

// 4. Try moving the uploaded file to the target location
if (move_uploaded_file($tempFile, $target)) {
    debug_output("Upload successful: File has been saved to $target");
    echo "Upload successful!";
} else {
    debug_output("Upload failed: Unable to move the file to target location $target");
    echo "Upload failed.";
}

?>
