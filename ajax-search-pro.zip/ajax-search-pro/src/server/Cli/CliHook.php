<?php

namespace WPDRMS\ASP\Cli;

use WP_CLI;
use WPDRMS\ASP\Hooks\Hook;

class CliHook implements Hook {
	public function register(): void {
		if ( !class_exists('WP_CLI') || !defined('WP_CLI') ) {
			return;
		}

		add_action(
			'cli_init',
			function () {
				WP_CLI::add_command('asp', '\WPDRMS\ASP\Cli\IndexTable');
			}
		);

		add_action(
			'cli_init',
			function () {
				WP_CLI::add_command('asp', '\WPDRMS\ASP\Cli\Cache');
			}
		);
	}

	public function deregister(): void {
		WP_CLI::add_command('asp', fn()=>null);
	}
}
