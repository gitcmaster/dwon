<div class="item">
	<?php
	$o = new wpdreamsYesNo("triggerontype", __('Trigger <strong>live</strong> search when typing?', 'ajax-search-pro'),
		$sd['triggerontype']);
	?>
</div>
<div class="item">
	<?php
	$o = new wpdreamsYesNo("trigger_on_facet", __('Trigger <strong>live</strong> search when changing a facet on settings (like checkboxes, drop-downs etc..)?', 'ajax-search-pro'),
		$sd['trigger_on_facet']);
	?>
	<p class="descMsg">
		<?php echo __('Will trigger the search if the user changes a checkbox, radio button, slider on the frontend
            search settings panel.', 'ajax-search-pro'); ?>
	</p>
</div>
<div class="item">
	<?php
	$o = new wpdreamsYesNo("trigger_update_href", __('Update the browser address bar with the last selected options?', 'ajax-search-pro'),
		$sd['trigger_update_href']);
	?>
	<p class="descMsg">
		<?php echo __('The current state of the search and the filters is reflected in the address bar and remembered for the browser back/forward buttons.', 'ajax-search-pro'); ?>
	</p>
</div>
<div class="item" wd-enable-on="triggerontype:1">
	<?php
	$o = new wpdreamsTextSmall("charcount", __('Minimal character count to trigger live search', 'ajax-search-pro'), $sd['charcount']);
	?>
	<p class="descMsg">
		<?php echo __('Default: 0', 'ajax-search-pro'); ?>
	</p>
</div>
<div class="item">
	<?php
	$o = new wpdreamsTextSmall("trigger_delay", __('Delay before triggering the live search after keystrokes or changing facets (in milliseconds)', 'ajax-search-pro'), $sd['trigger_delay']);
	?>
	<p class="descMsg">
		<?php echo __('When the user enters or deletes a character or changes a search facet, this is how much time the live search is delayed before it is triggered.', 'ajax-search-pro'); ?><br>
		<?php echo __('It prevents triggering too many requests while the user is typing or is actively changing the filters.', 'ajax-search-pro'); ?><br>
		<?php echo __('Default: 300', 'ajax-search-pro'); ?>
	</p>
</div>