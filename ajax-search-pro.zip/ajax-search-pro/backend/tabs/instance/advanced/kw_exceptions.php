<fieldset>
	<legend><?php _e('Keyword Exceptions', 'ajax-search-pro'); ?></legend>
	<p class="infoMsg"><?php echo __('Keyword exceptions will be replaced with an empty string "" in the search phrase.', 'ajax-search-pro'); ?></p>
	<div class="item">
		<?php
		new wd_TextareaExpandable("kw_exceptions", __('Keyword exceptions - replace anywhere', 'ajax-search-pro'), $sd['kw_exceptions']);
		?>
		<p class="descMsg"><?php echo __('<strong>Comma separated list</strong> of keywords you want to remove or ban. Matching anything, even partial words.', 'ajax-search-pro'); ?></p>
	</div>
	<div class="item">
		<?php
		new wd_TextareaExpandable("kw_exceptions_e", __('Keyword exceptions - replace whole words only', 'ajax-search-pro'), $sd['kw_exceptions_e']);
		?>
		<p class="descMsg"><?php echo __('<strong>Comma separated list</strong> of keywords you want to remove or ban. Only matching whole words between word boundaries.', 'ajax-search-pro'); ?></p>
	</div>
</fieldset>
<fieldset>
	<legend><?php _e('Transformations', 'ajax-search-pro'); ?></legend>
	<div class="item">
		<?php
		new wpdreamsYesNo("kw_transform_quotes", __('Resolve all types of quotes to Standard/ASCII single and double quotes', 'ajax-search-pro'), $sd['kw_transform_quotes']);
		?>
		<p class="descMsg"><?php echo __('Great to handle IOS smart punctuation. Transforms all user inputted non Standard/ASCII quotation marks (“, ”, ‘, ’, „, ‚, ‛) to ASCII, aka. \' and "', 'ajax-search-pro'); ?></p>
	</div>
</fieldset>