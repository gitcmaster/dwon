<div class="wdo" id="wdo"><div id="asp-root"></div></div>
<?php

use WPDRMS\ASP\Utils\Script;

$metadata = require_once ASP_PATH . 'build/css/wdo-global.asset.php';
wp_enqueue_style(
	'wpo-global',
	ASP_URL_NP . 'build/css/wdo-global.css',
	$metadata['dependencies'],
	$metadata['version'],
);



$metadata = require_once ASP_PATH . 'build/js/cache.asset.php';
wp_enqueue_script(
	'wpd-asp-cache',
	ASP_URL_NP . 'build/js/cache.js',
	$metadata['dependencies'],
	$metadata['version'],
	array( 'in_footer' =>true ),
);

$metadata = require_once __DIR__ . '/global.asset.php';
Script::objectToInlineScript(
	'wpd-asp-cache',
	'ASP_BACKEND',
	$metadata['ASP_BACKEND'],
	'before',
	true,
);
