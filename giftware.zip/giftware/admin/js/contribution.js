/**
 * All of the code for thankyou order on your admin-facing JavaScript source
 * should reside in this file.
 *
 * @package           Ultimate Woocommerce Gift Cards
 */

(function( $ ) {
	'use strict';

	$( document ).ready(
		function() {
            jQuery('#product-type').hide();
            
        })
})( jQuery );
