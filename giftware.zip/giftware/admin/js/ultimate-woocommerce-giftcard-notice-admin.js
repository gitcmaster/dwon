(function( $ ) {
    'use strict';
    // on clicking license check button
  //  var ajax_url = wps_gc_admin_notice_param.ajaxurl;
    $( document ).ready(  
        function(){
    $(document).on('click', '#wps_check_license', function(e){
        e.preventDefault();
        
        $.ajax({
            type: "POST",
            dataType: "JSON",
            url: wps_gc_admin_notice_param.ajaxurl,
            data: {
                action: "wps_giftware_check_license_key_status",
                nonce : wps_gc_admin_notice_param.nonce,
            },
       
            success: function(data) {
                
                if (data.status == true) {
                    jQuery("div.wps-subsc_notice p").html(data.msg);
                    setTimeout(function(){
                        location = wps_gc_admin_notice_param.gc_admin_param_location;
                    }, 2000);                  
                }
                else{
                    jQuery("div.wps-subsc_notice p").html(data.msg);
                    setTimeout(function(){
                        location = wps_gc_admin_notice_param.gc_admin_param_location;
                    }, 2000);
                }
            },
        })
        .fail(function ( response ) {
            location = wps_gc_admin_notice_param.gc_admin_param_location;
        });
       
    });
 
});
   
})( jQuery );